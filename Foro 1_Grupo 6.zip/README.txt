# Foro1POO
 
//Noé Marcelo Ortega Urías		OU232690
//Oscar Armando Munguía Sotelo		MS232185
//Diego Alberto Muñoz Chavez		MC191763
//Fernando Samuel Quijada Arévalo QA190088
//David Guillermo Cardona Pérez  CP121738


26 de Agosto del 2023
